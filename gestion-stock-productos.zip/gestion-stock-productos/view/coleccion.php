<?php
require '../db.php'; // Conexión a la base de datos

// Traer productos de la base de datos
$query = $conn->query("SELECT * FROM Productos");
$productos = [];
while($row = $query->fetch_assoc()){
    $productos[] = $row;
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Clothing Brand - Elegancia y Estilo</title>
  <link rel="icon" href="../img/iconopagina.png">
  
  <link rel="stylesheet" href="../css/style.css">
  <link rel="stylesheet" href="../css/menu.css">
  <link rel="stylesheet" href="../css/coleccion.css">
  <link rel="stylesheet" href="../css/reveral.css">
  <link rel="stylesheet" href="../css/estetica.css">
  <link rel="stylesheet" href="/proyecto1_final/assets/css/responsive.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  
  <script src="../js/reveral.js" defer></script>
  <script src="/proyecto1_final/assets/js/menu.js" defer></script>
  <style>
    /* Estilos básicos para el carrito flotante */
    #cart-popup {
      position: fixed;
      top: 70px;
      right: 20px;
      width: 300px;
      background: #fff;
      border: 1px solid #ccc;
      padding: 15px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.2);
      display: none;
      z-index: 1000;
    }
    #cart-popup ul { padding:0; margin:0; list-style:none; max-height:200px; overflow-y:auto; }
    #cart-popup h3 { margin-top:0; }
    #cart-icon { cursor: pointer; position: relative; }
    #cart-count {
      background: red;
      color: #fff;
      border-radius: 50%;
      padding: 2px 6px;
      font-size: 12px;
      position: absolute;
      top: -5px;
      right: -10px;
    }
    .hidden { display:none; }
  </style>
</head>

<body>
  <!-- HEADER -->
  <header>
    <div class="user-menu-container reveal">
      <div class="user-general reveal">
        <p class="username reveal">Usuario</p>
        <button class="user-icon-btn reveal" id="userBtn" aria-expanded="false" aria-controls="dropdownMenu">
          <img src="../php/css/img/user.png" alt="Usuario">
        </button>
      </div>
      <ul class="dropdown-menu reveal" id="dropdownMenu" role="menu">
        <li><a class="dropdown-item reveal" href="modification.php"><i class="fas fa-key"></i> Modificar contraseña</a></li>
        <li><a class="dropdown-item reveal" href="#" onclick="showDeleteConfirm()"><i class="fas fa-trash-alt"></i> Eliminar cuenta</a></li>
        <li class="dropdown-divider reveal"></li>
        <li><a class="dropdown-item reveal" href="#" onclick="logout()"><i class="fas fa-sign-out-alt"></i> Cerrar sesión</a></li>
      </ul>
    </div>

    <nav>
      <div class="logo reveal">
        <a href="index.php"><img src="../img/iconopagina.png" alt="Logo de la marca"></a>
      </div>

      <div class="hamburger reveal" id="hamburger">☰</div>

      <div class="nav-links reveal" id="nav-links">
        <ul>
          <li><a href="index.php">Inicio</a></li>
          <li><a href="coleccion.php">Colección</a></li>
          <li><a href="nosotros.php">Nosotros</a></li>
          <li><a href="contacto.php">Contacto</a></li>
        </ul>
      </div>

      <div class="search-bar reveal">
        <form action="#" method="get">
          <input type="search" placeholder="Buscar productos..." name="search">
          <button id="button-search" type="submit"><img src="../img/iconobuscar.png" alt="" width="20"></button>
        </form>
      </div>

      <div class="nav-icons reveal">
        <div id="cart-icon">
          <img src="../img/carritodecompras.png" alt="Carrito de compras" width="28" title="Carrito">
          <span id="cart-count">0</span>
        </div>
      </div>
    </nav>
  </header>

  <!-- BANNER -->
  <section class="banner-section">
    <img src="../img/coleccion/mujeranuncio.jpg" alt="Banner Colección" class="banner-coleccion reveal">
  </section>

  <!-- COLECCIÓN -->
  <section id="coleccion">
    <h2>Nuestra Colección</h2>
    <p>Explora nuestra selección de prendas cuidadosamente diseñadas para combinar estilo y comodidad. Desde looks casuales hasta elegantes, nuestra colección tiene algo para cada ocasión y personalidad.</p>
    
    <div class="filtros reveal">
      <button data-filter="todos">Todos</button>
      <button data-filter="camisas">Camisas</button>
      <button data-filter="pantalones">Pantalones</button>
      <button data-filter="chaquetas">Chaquetas</button>
      <button data-filter="accesorios">Accesorios</button>
    </div>

    <div class="gallery reveal">
      <?php foreach($productos as $prod): ?>
        <div class="product-item <?php echo strtolower($prod['Categoria'] ?? 'otros'); ?> reveal" data-stock="<?php echo $prod['StockActual']; ?>" data-id="<?php echo $prod['ProductoID']; ?>">
          <img src="<?php echo $prod['Imagen']; ?>" alt="<?php echo htmlspecialchars($prod['Nombre']); ?>">
          <h3><?php echo htmlspecialchars($prod['Nombre']); ?></h3>
          <p><?php echo htmlspecialchars($prod['Descripcion']); ?></p>
          <p class="precio">$<?php echo number_format($prod['Precio'],0,',','.'); ?></p>
          <div class="estrellas">⭐⭐⭐⭐☆</div>
          <button class="btn-comprar" data-id="<?php echo $prod['ProductoID']; ?>">Agregar al carrito</button>
          <button class="btn-detalles">Más detalles</button>
        </div>
      <?php endforeach; ?>
    </div>
  </section>

  <!-- MODAL DETALLES -->
  <div id="modal-detalles" class="modal hidden">
    <div class="modal-content">
      <span id="close-modal" class="close">&times;</span>
      <img id="modal-img" src="" alt="Imagen del producto">
      <h3 id="modal-title"></h3>
      <p id="modal-description"></p>
      <p id="modal-price"></p>
      <div id="modal-stars"></div>
      <button id="modal-add-cart" class="btn-comprar">Agregar al carrito</button>
    </div>
  </div>

  <!-- CARRITO -->
  <div id="cart-popup">
    <h3>🛒 Carrito de Compras</h3>
    <ul id="cart-items"></ul>
    <p>Total: <span id="cart-total">$0</span></p>
  </div>

  <!-- FOOTER -->
  <footer>
    <div class="footer-container reveal">
      <div class="footer-col brand-info">
        <img src="../img/iconopagina.png" alt="Logo de la marca" class="footer-logo">
        <p>Elegancia y estilo en cada prenda. Inspirados en la autenticidad, diseñamos ropa para destacar tu personalidad.</p>
      </div>
      <div class="footer-col">
        <h3>Enlaces rápidos</h3>
        <ul>
          <li><a href="#inicio">Inicio</a></li>
          <li><a href="#coleccion">Colección</a></li>
          <li><a href="#nosotros">Nosotros</a></li>
          <li><a href="#contacto">Contacto</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h3>Atención al cliente</h3>
        <ul>
          <li><a href="#">Preguntas frecuentes</a></li>
          <li><a href="#">Envíos y devoluciones</a></li>
          <li><a href="#">Términos y condiciones</a></li>
          <li><a href="#">Política de privacidad</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h3>Conéctate con nosotros</h3>
        <div class="social-icons">
          <a href="#"><img src="../img/instagram.png" alt="Instagram"></a>
          <a href="#"><img src="../img/facebook.png" alt="Facebook"></a>
          <a href="#"><img src="../img/twitter.png" alt="Twitter"></a>
        </div>
        <p class="footer-mail">📧 info@marcaropa.com</p>
      </div>
    </div>
    <div class="footer-bottom reveal">
      <p>© 2025 Marca Ropa. Todos los derechos reservados.</p>
    </div>
  </footer>

  <script>
    let carrito = [];

    // Modal detalles
    document.addEventListener('DOMContentLoaded', () => {
      const modal = document.getElementById('modal-detalles');
      const modalImg = document.getElementById('modal-img');
      const modalTitle = document.getElementById('modal-title');
      const modalDesc = document.getElementById('modal-description');
      const modalPrice = document.getElementById('modal-price');
      const modalStars = document.getElementById('modal-stars');
      const closeModal = document.getElementById('close-modal');

      document.querySelectorAll('.btn-detalles').forEach(boton => {
        boton.addEventListener('click', () => {
          const product = boton.closest('.product-item');
          modalImg.src = product.querySelector('img').src;
          modalTitle.textContent = product.querySelector('h3').textContent;
          modalDesc.textContent = product.querySelector('p').textContent;
          modalPrice.textContent = product.querySelector('.precio').textContent;
          modalStars.innerHTML = product.querySelector('.estrellas').innerHTML;
          modal.classList.remove('hidden');
        });
      });

      closeModal.addEventListener('click', () => modal.classList.add('hidden'));
      window.addEventListener('click', e => { if(e.target===modal) modal.classList.add('hidden'); });
    });

    // Filtro productos
    document.querySelectorAll('.filtros button').forEach(boton => {
      boton.addEventListener('click', () => {
        const filtro = boton.dataset.filter;
        document.querySelectorAll('.gallery .product-item').forEach(prod => {
          prod.style.display = filtro==='todos'||prod.classList.contains(filtro)?'block':'none';
        });
      });
    });

    // Carrito funcional
    const cartIcon = document.getElementById('cart-icon');
    const cartPopup = document.getElementById('cart-popup');

    cartIcon.addEventListener('click', () => {
      cartPopup.style.display = cartPopup.style.display==='block'?'none':'block';
    });

    document.querySelectorAll('.btn-comprar').forEach(btn => {
      btn.addEventListener('click', () => {
        const product = btn.closest('.product-item');
        const id = btn.dataset.id;
        const nombre = product.querySelector('h3').textContent;
        const precio = parseInt(product.querySelector('.precio').textContent.replace(/[^0-9]/g,''));
        const stock = parseInt(product.dataset.stock || 0);

        if(stock<=0){ alert('Producto agotado'); return; }

        let item = carrito.find(i=>i.id==id);
        if(item){
          if(item.cantidad<stock) item.cantidad++;
          else { alert('No hay más stock disponible'); return; }
        } else carrito.push({id,nombre,precio,cantidad:1});

        actualizarCarrito();
      });
    });

    function actualizarCarrito(){
      const lista = document.getElementById('cart-items');
      lista.innerHTML = '';
      let total = 0;
      carrito.forEach(item => {
        const li = document.createElement('li');
        li.textContent = `${item.nombre} x${item.cantidad} - $${item.precio*item.cantidad}`;
        lista.appendChild(li);
        total += item.precio*item.cantidad;
      });
      document.getElementById('cart-total').textContent=`$${total}`;
      document.getElementById('cart-count').textContent=carrito.length;
    }
  </script>
</body>
</html>