<?php
header("refresh:5;url=php/register.php");
?>