-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 02-11-2025 a las 18:36:52
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `productos`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `ProductoID` int(11) NOT NULL,
  `Nombre` varchar(100) NOT NULL,
  `Descripcion` text DEFAULT NULL,
  `Imagen` varchar(255) DEFAULT NULL,
  `Precio` decimal(10,2) NOT NULL CHECK (`Precio` > 0),
  `StockActual` int(11) NOT NULL DEFAULT 0 CHECK (`StockActual` >= 0),
  `StockMaximo` int(11) NOT NULL DEFAULT 30 CHECK (`StockMaximo` = 30),
  `Estado` varchar(20) NOT NULL DEFAULT 'Disponible' CHECK (`Estado` in ('Disponible','Agotado'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`ProductoID`, `Nombre`, `Descripcion`, `Imagen`, `Precio`, `StockActual`, `StockMaximo`, `Estado`) VALUES
(1, 'Camisa minimalista', 'Camisa de algodón con detalles minimalistas.', '../img/producto1.jpg', 24990.00, 15, 30, 'Disponible'),
(2, 'Pantalones suaves', 'Pantalones de corte recto y tela suave.', '../img/producto2.jpg', 29990.00, 12, 30, 'Disponible'),
(3, 'Chaqueta versátil', 'Chaqueta ligera ideal para cualquier ocasión.', '../img/producto3.jpg', 34990.00, 10, 30, 'Disponible'),
(4, 'Vestido elegante', 'Vestido elegante para eventos especiales.', '../img/producto4.jpg', 39990.00, 8, 30, 'Disponible'),
(5, 'Suéter acogedor', 'Suéter de lana suave ideal para climas fríos.', '../img/foto1A.jpg', 27990.00, 10, 30, 'Disponible'),
(6, 'Camiseta básica', 'Camiseta de algodón ligera y cómoda para uso diario.', '../img/foto2A.jpg', 14990.00, 25, 30, 'Disponible'),
(7, 'Blazer elegante', 'Blazer moderno perfecto para eventos formales o de oficina.', '../img/foto3A.jpg', 44990.00, 6, 30, 'Disponible'),
(8, 'Sudadera casual', 'Sudadera con capucha y bolsillo frontal, ideal para un look urbano.', '../img/foto4A.jpg', 22990.00, 20, 30, 'Disponible'),
(9, 'Shorts frescos', 'Shorts de algodón para días cálidos y estilo relajado.', '../img/foto5A.jpg', 19990.00, 30, 30, 'Disponible'),
(10, 'Abrigo clásico', 'Abrigo largo con corte moderno para la temporada invernal.', '../img/foto6A.jpg', 54990.00, 5, 30, 'Disponible'),
(11, 'Chaqueta de Cuero', 'Chaqueta cómoda y negra de hombre con un estilo rockero.', '../img/foto8A.jpg', 59990.00, 4, 30, 'Disponible'),
(12, 'Traje Azul Elegante', 'Traje Azul moderno y elegante, ideal para eventos especiales.', '../img/foto9A.jpg', 89990.00, 3, 30, 'Disponible'),
(13, 'Bufanda moderna', 'Bufanda de lana tejida, perfecta para complementar tu outfit.', '../img/foto10A.jpg', 12990.00, 40, 30, 'Disponible'),
(14, 'Camisa Negra', 'Camisa Negra de hombre y moderna pegada al cuerpo, perfecta para lucir bien y fresco.', '../img/foto11A.jpg', 26990.00, 10, 30, 'Disponible'),
(15, 'Pantalon de Vestir', 'Pantalon de Vestir Azul Oscuro y moderno, ideal para eventos importantes.', '../img/foto12A.jpg', 34990.00, 7, 30, 'Disponible');

--
-- Disparadores `productos`
--
DELIMITER $$
CREATE TRIGGER `trg_control_stock` BEFORE UPDATE ON `productos` FOR EACH ROW BEGIN
    -- Si el producto se queda sin stock
    IF NEW.StockActual <= 0 THEN
        SET NEW.StockActual = 0;
        SET NEW.Estado = 'Agotado';
    END IF;

    -- Si se repone el stock
    IF NEW.StockActual > 0 THEN
        SET NEW.Estado = 'Disponible';
    END IF;
END
$$
DELIMITER ;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`ProductoID`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `ProductoID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
