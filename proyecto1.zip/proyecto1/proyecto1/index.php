<?php
header("refresh:5;url=views/register.php");
?>