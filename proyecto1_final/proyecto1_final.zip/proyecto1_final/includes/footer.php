<?php
// Footer común
?>
</body>
</html>
